public interface FormatadorPessoa {
    String formatarPessoa();
}