package modelos;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import colletion.ControlaCrianca;



public class Turma {
    private int idTurma;
    private String turno;
    private Set<Crianca> criancasMatriculadas;

    public int getIdTurma() {
        return idTurma;
    }

    public void setIdTurma(int idTurma) {
        this.idTurma = idTurma;
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    public ArrayList<Crianca> getCriancasMatriculadas() {
        return new ArrayList<>(criancasMatriculadas);
    }


    public void setCriancasMatriculadas(Set<Crianca> criancasMatriculadas) {
        this.criancasMatriculadas = criancasMatriculadas;
    }

    public Turma() {

    }


    public Turma(int idTurma, String turno) {
        this.idTurma = idTurma;
        this.turno = turno;
        this.criancasMatriculadas = new HashSet<>();
    }

    public boolean matricularCriancaPorID(int idCrianca) {
        ControlaCrianca controlaCrianca = new ControlaCrianca();
        Crianca crianca = controlaCrianca.encontrarPorId(idCrianca);

        if (crianca != null) {
            if (criancasMatriculadas.contains(crianca)) {
                System.out.println("A criança já está matriculada na turma " + idTurma);
                return true; // A criança já está matriculada
            } else {
                criancasMatriculadas.add(crianca);
                System.out.println("Criança matriculada com sucesso na turma " + idTurma);
                return false; // Matrícula bem-sucedida
            }
        } else {
            System.out.println("Criança não encontrada com base no ID fornecido.");
            return true; // Criança não encontrada
        }
    }
}