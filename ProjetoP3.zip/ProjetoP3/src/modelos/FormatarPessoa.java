package modelos;

public interface FormatarPessoa {
    String formatarPessoa();
}
