package modelos;

public class Departamento {
    private int idDepart;
    private String nomeDepart;
    private int quantFuncionarios;


    public Departamento(int id, String nome) {
        this.idDepart = id;
        this.nomeDepart = nome;
    }

    public int getId() {
        return idDepart;
    }

    public void setId(int id) {
        this.idDepart = id;
    }

    public String getNome() {
        return nomeDepart;
    }

    public void setNome(String nome) {
        this.nomeDepart = nome;
    }

    public int getQuantFuncionarios() {
        return quantFuncionarios;
    }

    public void setQuantFuncionarios(int quantFuncionarios) {
        this.quantFuncionarios = quantFuncionarios;
    }


    public int getIdDepartamento() {
        return getIdDepartamento();
    }
}

