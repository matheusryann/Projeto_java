package modelos;



public class Crianca extends Pessoa implements FormatarPessoa {
    String nomeResponsavel;


    public Crianca(String nome, String cpf, String dataNascimento, int id, String nomeResponsavel) {
        super(nome, cpf, dataNascimento, id);
        this.nomeResponsavel = nomeResponsavel;
    }


    public String getNomeResponsavel() {
        return nomeResponsavel;
    }

    public void setNomeResponsavel(String nomeResponsavel) {
        this.nomeResponsavel = nomeResponsavel;
    }




    @Override
    public String formatarPessoa() {
        return "Nome: " + getNome() + ", CPF: " + getCpf() + ", Data de Nascimento: " + getDataNascimento() + ", ID: " + getId()+ ", Nome do Responsavél: " +nomeResponsavel;
    }
}
