package gui;
import colletion.ControlaFuncionario;
import modelos.Departamento;
import modelos.Funcionario;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

        public class GUIFuncionario extends JFrame {
            private JTextField nomeFunc;
            private JTextField cpfFunc;
            private JTextField dataFunc;
            private JTextField idFunc;
            private JTextField funcaoFunc;
            private JTextField salarioFunc;
            private JTextField numeroContFunc;
            private JButton cadastrarBtn;
            private JButton verBtn;
            private JButton atualizarBtn;
            private JButton excluirBtn;
            private JButton voltarBtn;
            private ControlaFuncionario controlaFuncionario;


            public GUIFuncionario() {
                setTitle("Cadastro para funcionario");
                setSize(500, 500);
                setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                JPanel panel = new JPanel();
                panel.setLayout(new FlowLayout(FlowLayout.LEFT));

                JLabel nomeLabel = new JLabel("Nome do Funcionário:");
                nomeFunc = new JTextField(50);

                JLabel cpfLabel = new JLabel("CPF do Funcionário:");
                cpfFunc = new JTextField(50);

                JLabel dataLabel = new JLabel("Data de Nascimento do Funcionário:");
                dataFunc = new JTextField(50);

                JLabel idLabel = new JLabel("ID do Funcionário:");
                idFunc = new JTextField(50);

                JLabel funcaoLabel = new JLabel("Função do Funcionário:");
                funcaoFunc = new JTextField(50);
                JLabel salarioLabel = new JLabel("Salário do Funcionário:");
                salarioFunc = new JTextField(50);
                JLabel numeroContatoLabel = new JLabel("Telefone de contato do Funcionário:");
                numeroContFunc = new JTextField(50);


                panel.add(nomeLabel);
                panel.add(nomeFunc);
                panel.add(idLabel);
                panel.add(idFunc);
                panel.add(cpfLabel);
                panel.add(cpfFunc);
                panel.add(dataLabel);
                panel.add(dataFunc);
                panel.add(idLabel);
                panel.add(idFunc);
                panel.add(funcaoLabel);
                panel.add(funcaoFunc);
                panel.add(salarioLabel);
                panel.add(salarioFunc);
                panel.add(numeroContatoLabel);
                panel.add(numeroContFunc);


                add(panel, BorderLayout.CENTER);


                JPanel buttonPanel = new JPanel();

                cadastrarBtn = new JButton("Cadastrar");
                verBtn = new JButton("Ver");
                atualizarBtn = new JButton("Atualizar");
                excluirBtn = new JButton("Excluir");
                voltarBtn = new JButton("Voltar");

                buttonPanel.add(cadastrarBtn);
                buttonPanel.add(verBtn);
                buttonPanel.add(atualizarBtn);
                buttonPanel.add(excluirBtn);
                buttonPanel.add(voltarBtn);

                add(buttonPanel, BorderLayout.SOUTH);

                ControlaFuncionario controlaFuncionario = new ControlaFuncionario();

                voltarBtn.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        dispose(); // Fecha a janela atual
                        GUIPrincipal GUIPrincipal = new GUIPrincipal();
                        GUIPrincipal.setVisible(true); // Exibe a janela principal
                    }
                });


                cadastrarBtn.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        String nome = nomeFunc.getText();
                        String cpf = cpfFunc.getText();
                        String dataNascimento = dataFunc.getText();
                        String idText = idFunc.getText();
                        String funcao = funcaoFunc.getText();
                        String salarioText = salarioFunc.getText();
                        String numeroContatoText = numeroContFunc.getText();

                        if (nome.isEmpty() || cpf.isEmpty() || dataNascimento.isEmpty() || idText.isEmpty() || funcao.isEmpty() || salarioText.isEmpty() || numeroContatoText.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "Por favor, preencha todos os campos.", "Campos Vazios", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        if (!cpf.matches("\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2}")) {
                            JOptionPane.showMessageDialog(null, "Formato de CPF inválido. Use xxx.xxx.xxx-xx.", "CPF Inválido", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        long numeroContato = Long.parseLong(numeroContatoText);

                        ArrayList<Funcionario> funcionarios = controlaFuncionario.listar();

                        for (Funcionario funcionarioExistente : funcionarios) {
                            if (funcionarioExistente.getCpf().equals(cpf)) {
                                JOptionPane.showMessageDialog(null, "CPF já cadastrado. Por favor, insira um CPF único.", "CPF Duplicado", JOptionPane.ERROR_MESSAGE);
                                return;
                            }
                        }

                        int id = Integer.parseInt(idText);
                        for (Funcionario funcionarioExistente : funcionarios) {
                            if (funcionarioExistente.getId() == id) {
                                JOptionPane.showMessageDialog(null, "ID de funcionário já cadastrado. Use um ID único.", "ID Duplicado", JOptionPane.ERROR_MESSAGE);
                                return; // Retorna sem cadastrar se o ID já existe
                            }
                        }
                        double salario = Double.parseDouble(salarioText);

                        Funcionario funcionario = new Funcionario(nome, cpf, dataNascimento, id, funcao, salario, numeroContato);
                        funcionario.setNumeroContato(numeroContato);

                        if (controlaFuncionario.cadastrar(funcionario)) {
                            JOptionPane.showMessageDialog(null, "Funcionário cadastrado com sucesso.");
                        } else {
                            JOptionPane.showMessageDialog(null, "Erro ao cadastrar o funcionário.", "Erro", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                });


                verBtn.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        ArrayList<Funcionario> funcionarios = controlaFuncionario.listar();

                        if (funcionarios.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "Nenhum funcionário cadastrado.", "Lista Vazia", JOptionPane.INFORMATION_MESSAGE);
                            return;
                        }

                        StringBuilder funcionariosInfo = new StringBuilder("Funcionários Cadastrados:\n\n");
                        for (Funcionario funcionario : funcionarios) {
                            funcionariosInfo.append("ID: ").append(funcionario.getId()).append("\n");
                            funcionariosInfo.append("Nome: ").append(funcionario.getNome()).append("\n");
                            funcionariosInfo.append("CPF: ").append(funcionario.getCpf()).append("\n");
                            funcionariosInfo.append("Data de Nascimento: ").append(funcionario.getDataNascimento()).append("\n");
                            funcionariosInfo.append("Função: ").append(funcionario.getFuncao()).append("\n");
                            funcionariosInfo.append("Salário: ").append(funcionario.getSalario()).append("\n");
                            funcionariosInfo.append("Número de Contato: ").append(funcionario.getNumeroContato()).append("\n\n");
                        }

                        JOptionPane.showMessageDialog(null, funcionariosInfo.toString(), "Funcionários Cadastrados", JOptionPane.INFORMATION_MESSAGE);
                    }
                });

                atualizarBtn.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        String idText = idFunc.getText();
                        if (idText.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "Digite o ID do funcionário para atualizar.", "Campo Vazio", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        int id = Integer.parseInt(idText);
                        Funcionario funcionarioAtualizado = controlaFuncionario.buscarPorId(id);

                        if (funcionarioAtualizado != null) {
                            // Preencha os campos de texto com os dados atuais do funcionário
                            nomeFunc.setText(funcionarioAtualizado.getNome());
                            cpfFunc.setText(funcionarioAtualizado.getCpf());
                            dataFunc.setText(funcionarioAtualizado.getDataNascimento());
                            funcaoFunc.setText(funcionarioAtualizado.getFuncao());
                            salarioFunc.setText(String.valueOf(funcionarioAtualizado.getSalario()));
                            numeroContFunc.setText(String.valueOf(funcionarioAtualizado.getNumeroContato()));
                        } else {
                            JOptionPane.showMessageDialog(null, "Funcionário não encontrado com base no ID informado.", "Funcionário não encontrado", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                });

                excluirBtn.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        String idText = idFunc.getText();
                        if (idText.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "Digite o ID do funcionário para excluir.", "Campo Vazio", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        int id = Integer.parseInt(idText);
                        boolean excluido = controlaFuncionario.excluir(id);

                        if (excluido) {
                            JOptionPane.showMessageDialog(null, "Funcionário excluído com sucesso.");
                            // Limpar os campos de texto após a exclusão
                            nomeFunc.setText("");
                            cpfFunc.setText("");
                            dataFunc.setText("");
                            idFunc.setText("");
                            funcaoFunc.setText("");
                            salarioFunc.setText("");
                            numeroContFunc.setText("");
                        } else {
                            JOptionPane.showMessageDialog(null, "Erro ao excluir o funcionário.", "Erro", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                });
            }


                public static void main (String[]args){
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            GUIFuncionario janela = new GUIFuncionario();
                            janela.setVisible(true);
                        }
                    });
                }
            }






