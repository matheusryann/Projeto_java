package gui;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GUIPrincipal extends JFrame {
    public GUIPrincipal() {
        setTitle("Sistema");
        setSize(600, 400);

        // Crie um painel principal para organizar os componentes
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS)); // Use um layout vertical

        // Crie o primeiro JLabel
        JLabel tituloLabel = new JLabel("    SISTEMA DE CADASTRO - CRECHE ESCOLAR  ");
        Font font = new Font("Arial", Font.BOLD, 20);
        tituloLabel.setFont(font);
        tituloLabel.setHorizontalAlignment(SwingConstants.CENTER);
        tituloLabel.setVerticalAlignment(SwingConstants.TOP);

        // Adicione o primeiro JLabel ao painel
        panel.add(tituloLabel);

        panel.add(Box.createRigidArea(new Dimension(0, 150)));

        // Crie o segundo JLabel
        JLabel campo1 = new JLabel("Selecione a entidade que deseja operar :");
        Font font2 = new Font("Arial", Font.BOLD, 15);
        campo1.setFont(font2);
        campo1.setHorizontalAlignment(SwingConstants.LEFT);

        // Adicione o segundo JLabel ao painel
        panel.add(campo1);

        // Crie um JComboBox com as opções
        String[] opcoes = {"Selecione", "Criança", "Funcionário", "Turma", "Departamento"};
        JComboBox<String> comboBox = new JComboBox<>(opcoes);

        // Defina o tamanho preferido do JComboBox
        comboBox.setPreferredSize(new Dimension(150, 30));

        // Crie um painel para o JComboBox
        JPanel comboBoxPanel = new JPanel();
        comboBoxPanel.setLayout(new FlowLayout(FlowLayout.CENTER)); // Alinhe à esquerda
        comboBoxPanel.add(comboBox);

        // Adicione o painel do JComboBox ao painel principal
        panel.add(comboBoxPanel);
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton irButton = new JButton("Ir");
        irButton.setPreferredSize(new Dimension(75, 20));
        JButton sairButton = new JButton("Sair");
        sairButton.setPreferredSize(new Dimension(150, 20));


        irButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String selectedItem = (String) comboBox.getSelectedItem(); // Obtém a seleção da caixinha

                if ("Selecione".equals(selectedItem)) {
                    // Exibe uma mensagem de erro se "Selecione" estiver selecionado
                    JOptionPane.showMessageDialog(null, "Erro: escolha entre Criança, Funcionário, Turma ou Departamento", "Erro", JOptionPane.ERROR_MESSAGE);
                } else {
                    // Abre a segunda janela apenas se "Criança" ou "Funcionário" forem selecionados
                    if ("Criança".equals(selectedItem) || "Funcionário".equals(selectedItem) || "Turma".equals(selectedItem) || "Departamento".equals(selectedItem)) {
                        // Abre a janela apropriada com base na seleção
                        if ("Criança".equals(selectedItem)) {
                            GUICrianca segundaJanela = new GUICrianca();
                            segundaJanela.setVisible(true);
                        } else if ("Funcionário".equals(selectedItem)) {
                            GUIFuncionario segundaJanela = new GUIFuncionario();
                            segundaJanela.setVisible(true);
                        } else if ("Turma".equals(selectedItem)) {
                            GUITurma segundaJanela = new GUITurma();
                            segundaJanela.setVisible(true);
                        } else if ("Departamento".equals(selectedItem)) {
                            GUIDepartamento segundaJanela = new GUIDepartamento();
                            segundaJanela.setVisible(true);
                        }
                    }
                }
            }
        });

        // Adicione ação para o botão "Sair"
        sairButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0); // Fecha a aplicação
            }
        });
        buttonPanel.add(irButton);
        buttonPanel.add(sairButton);
        // Adicione o painel de botões ao painel principal
        panel.add(buttonPanel);
        // Adicione o painel à janela
        add(panel);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GUIPrincipal GUIPrincipal = new GUIPrincipal();
            GUIPrincipal.setVisible(true);
        });
    }
}
