package gui;
import colletion.ControlaDepartamento;
import modelos.Departamento;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GUIDepartamento extends JFrame {
    private JTextField idDepartamento;
    private JTextField nomeDepartamento;
    private JTextField quantFunc;
    private JButton cadastrarbtn;
    private JButton verbtn;
    private JButton atualizarbtn;
    private JButton excluirbtn;
    private JButton voltarbtn;
    private ControlaDepartamento controlaDepartamento;
    private Departamento departamento;

    public GUIDepartamento() {
        setTitle("Cadastro de Departamento");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout(FlowLayout.LEFT));

        JLabel idLabel = new JLabel("ID do Departamento:");
        idDepartamento = new JTextField(50);

        JLabel nomeLabel = new JLabel("Nome:");
        nomeDepartamento = new JTextField(50);

        JLabel quantLabel = new JLabel("Quantidade de funcionários do departamento:");
        quantFunc = new JTextField(50);


        panel.add(idLabel);
        panel.add(idDepartamento);
        panel.add(nomeLabel);
        panel.add(nomeDepartamento);
        panel.add(quantLabel);
        panel.add(quantFunc);


        add(panel, BorderLayout.CENTER);
        JPanel buttonPanel = new JPanel();

        cadastrarbtn = new JButton("Cadastrar");
        verbtn = new JButton("Ver");
        atualizarbtn = new JButton("Atualizar");
        excluirbtn = new JButton("Excluir");
        voltarbtn = new JButton("Voltar");

        buttonPanel.add(cadastrarbtn);
        buttonPanel.add(verbtn);
        buttonPanel.add(atualizarbtn);
        buttonPanel.add(excluirbtn);
        buttonPanel.add(voltarbtn);

        add(buttonPanel, BorderLayout.SOUTH);


        controlaDepartamento = new ControlaDepartamento();


        voltarbtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Fecha a janela atual
                GUIPrincipal GUIPrincipal = new GUIPrincipal();
                GUIPrincipal.setVisible(true); // Exibe a janela principal
            }
        });

        cadastrarbtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String idText = idDepartamento.getText();
                String nomeText = nomeDepartamento.getText();
                String quantFuncText = quantFunc.getText();

                if (idText.isEmpty() || nomeText.isEmpty() || quantFuncText.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor, preencha todos os campos.", "Campos Vazios", JOptionPane.ERROR_MESSAGE);
                    return; // Retorna sem fazer nada se algum campo estiver vazio
                }

                try {
                    int id = Integer.parseInt(idText);
                    ArrayList<Departamento> departamentos = controlaDepartamento.retornarTodos();
                    for (Departamento departamentoExistente : departamentos) {
                        if (departamentoExistente.getId() == id) {
                            JOptionPane.showMessageDialog(null, "ID de departamento já cadastrado. Use um ID único.", "ID Duplicado", JOptionPane.ERROR_MESSAGE);
                            return; // Retorna sem cadastrar se o ID já existe
                        }
                    }
                    int quantFuncionarios = Integer.parseInt(quantFuncText);

                    Departamento departamento = new Departamento(id, nomeText);
                    departamento.setQuantFuncionarios(quantFuncionarios);

                    if (controlaDepartamento.salvar(departamento)) {
                        JOptionPane.showMessageDialog(null, "Departamento cadastrado com sucesso.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Erro ao cadastrar o departamento.", "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "O ID e a quantidade de funcionários devem ser números inteiros.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        verbtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ArrayList<Departamento> departamentos = controlaDepartamento.retornarTodos();
                if (!departamentos.isEmpty()) {
                    StringBuilder info = new StringBuilder("Departamentos cadastrados:\n");
                    for (Departamento departamento : departamentos) {
                        info.append("ID: ").append(departamento.getId()).append(", Nome: ").append(departamento.getNome()).append(", Quantidade de Funcionários: ").append(departamento.getQuantFuncionarios()).append("\n");
                    }
                    JOptionPane.showMessageDialog(null, info.toString());
                } else {
                    JOptionPane.showMessageDialog(null, "Nenhum departamento cadastrado.");
                }
            }
        });

        atualizarbtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String idText = idDepartamento.getText();
                if (idText.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor, informe o ID do departamento que deseja atualizar.", "Campo ID Vazio", JOptionPane.ERROR_MESSAGE);
                    return; // Retorna sem fazer nada se o ID estiver vazio
                }

                int id = Integer.parseInt(idText);
                String nome = nomeDepartamento.getText();
                int quantFuncionarios = Integer.parseInt(quantFunc.getText());

                Departamento departamentoAtualizado = new Departamento(id, nome);
                departamentoAtualizado.setQuantFuncionarios(quantFuncionarios);

                if (controlaDepartamento.atualizar(departamentoAtualizado)) {
                    JOptionPane.showMessageDialog(null, "Departamento atualizado com sucesso.");
                } else {
                    JOptionPane.showMessageDialog(null, "Erro ao atualizar o departamento. Departamento não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        excluirbtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String idText = idDepartamento.getText();
                if (idText.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor, informe o ID do departamento que deseja excluir.", "Campo ID Vazio", JOptionPane.ERROR_MESSAGE);
                    return; // Retorna sem fazer nada se o ID estiver vazio
                }

                int id = Integer.parseInt(idText);

                if (controlaDepartamento.excluir(id)) {
                    JOptionPane.showMessageDialog(null, "Departamento excluído com sucesso.");
                } else {
                    JOptionPane.showMessageDialog(null, "Erro ao excluir o departamento. Departamento não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

        public static void main (String[]args){
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    GUIDepartamento janela = new GUIDepartamento();
                    janela.setVisible(true);
                }
            });
        }
    }



