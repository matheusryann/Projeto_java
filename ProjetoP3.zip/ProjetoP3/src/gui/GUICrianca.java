package gui;
import colletion.ControlaCrianca;
import modelos.Crianca;
import modelos.Departamento;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GUICrianca extends JFrame {
    private JTextField nomeField;
    private JTextField cpfField;
    private JTextField dataField;
    private JTextField idField;
    private JTextField nome2Field;
    private JButton cadastrarButton;
    private JButton verButton;
    private JButton atualizarButton;
    private JButton excluirButton;
    private JButton voltarButton;
    private ControlaCrianca controlaCrianca;


    public GUICrianca() {
        setTitle("Cadastro para Criança");
        setSize(600, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout(FlowLayout.LEFT));

        JLabel nomeLabel = new JLabel("Nome da Criança:");
        nomeField = new JTextField(50);

        JLabel cpfLabel = new JLabel("CPF da Criança:");
        cpfField = new JTextField(50);

        JLabel dataLabel = new JLabel("Data de Nascimento da Criança:");
        dataField = new JTextField(50);

        JLabel idLabel = new JLabel("ID da Criança:");
        idField = new JTextField(50);

        JLabel nome2Label = new JLabel("Nome responsável da Criança:");
        nome2Field = new JTextField(50);


        panel.add(nomeLabel);
        panel.add(nomeField);
        panel.add(cpfLabel);
        panel.add(cpfField);
        panel.add(dataLabel);
        panel.add(dataField);
        panel.add(idLabel);
        panel.add(idField);
        panel.add(nome2Label);
        panel.add(nome2Field);

        add(panel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();

        cadastrarButton = new JButton("Cadastrar");
        verButton = new JButton("Ver");
        atualizarButton = new JButton("Atualizar");
        excluirButton = new JButton("Excluir");
        voltarButton = new JButton("Voltar");
        buttonPanel.add(cadastrarButton);

        buttonPanel.add(verButton);
        buttonPanel.add(atualizarButton);
        buttonPanel.add(excluirButton);
        buttonPanel.add(voltarButton);
        add(buttonPanel, BorderLayout.SOUTH);

        ControlaCrianca controlaCrianca = new ControlaCrianca();


        voltarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Fecha a janela atual
                GUIPrincipal GUIPrincipal = new GUIPrincipal();
                GUIPrincipal.setVisible(true); // Exibe a janela principal
            }
        });

        cadastrarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nome = nomeField.getText();
                String cpf = cpfField.getText();
                String dataNascimento = dataField.getText();
                String idText = idField.getText();
                String nomeResponsavel = nome2Field.getText();

                if (nome.isEmpty() || cpf.isEmpty() || dataNascimento.isEmpty() || idText.isEmpty() || nomeResponsavel.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor, preencha todos os campos.", "Campos Vazios", JOptionPane.ERROR_MESSAGE);
                    return; // Retorna sem fazer nada se algum campo estiver vazio
                }

                if (!cpf.matches("\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2}")) {
                    JOptionPane.showMessageDialog(null, "Formato de CPF inválido. Use xxx.xxx.xxx-xx.", "CPF Inválido", JOptionPane.ERROR_MESSAGE);
                    return; // Retorna sem fazer nada se o CPF estiver no formato incorreto
                }

                int id = Integer.parseInt(idText);
                ArrayList<Crianca> criancas = controlaCrianca.retornarTodos();
                for (Crianca criancaExistente : criancas) {
                    if (criancaExistente.getId() == id) {
                        JOptionPane.showMessageDialog(null, "ID da criança já cadastrado. Use um ID único.", "ID Duplicado", JOptionPane.ERROR_MESSAGE);
                        return; // Retorna sem cadastrar se o ID já existe
                    }
                }

                for (Crianca criancaExistente : criancas) {
                    if (criancaExistente.getCpf().equals(cpf)) {
                        JOptionPane.showMessageDialog(null, "CPF já cadastrado. Por favor, insira um CPF único.", "CPF Duplicado", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                Crianca crianca = new Crianca(nome, cpf, dataNascimento, id, nomeResponsavel);

                if (controlaCrianca.salvar(crianca)) {
                    JOptionPane.showMessageDialog(null, "Criança cadastrada com sucesso.");
                } else {
                    JOptionPane.showMessageDialog(null, "Erro ao cadastrar a criança.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        verButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ArrayList<Crianca> criancas = controlaCrianca.retornarTodos();
                if (!criancas.isEmpty()) {
                    StringBuilder info = new StringBuilder("Crianças cadastradas:\n");
                    for (Crianca crianca : criancas) {
                        info.append(crianca.formatarPessoa()).append("\n");
                    }
                    JOptionPane.showMessageDialog(null, info.toString());
                } else {
                    JOptionPane.showMessageDialog(null, "Nenhuma criança cadastrada.");
                }
            }
        });

        atualizarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String idText = idField.getText();
                if (idText.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor, informe o ID da criança que deseja atualizar.", "Campo ID Vazio", JOptionPane.ERROR_MESSAGE);
                    return; // Retorna sem fazer nada se o ID estiver vazio
                }

                int idParaAtualizar = Integer.parseInt(idText);
                Crianca criancaAtualizada = new Crianca(
                        nomeField.getText(),
                        cpfField.getText(),
                        dataField.getText(),
                        idParaAtualizar,
                        nome2Field.getText()
                );

                if (controlaCrianca.atualizar(criancaAtualizada)) {
                    JOptionPane.showMessageDialog(null, "Criança atualizada com sucesso.");
                } else {
                    JOptionPane.showMessageDialog(null, "Erro ao atualizar a criança.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        excluirButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String idText = idField.getText();
                if (idText.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor, informe o ID da criança que deseja excluir.", "Campo ID Vazio", JOptionPane.ERROR_MESSAGE);
                    return; // Retorna sem fazer nada se o ID estiver vazio
                }

                int idParaExcluir = Integer.parseInt(idText);
                if (controlaCrianca.excluir(idParaExcluir)) {
                    JOptionPane.showMessageDialog(null, "Criança excluída com sucesso.");
                } else {
                    JOptionPane.showMessageDialog(null, "Erro ao excluir a criança.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                GUICrianca janela = new GUICrianca();
                janela.setVisible(true);
            }
        });
    }
}
