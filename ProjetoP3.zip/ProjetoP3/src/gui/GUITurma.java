package gui;
import colletion.ControlaTurma;
import colletion.ControlaCrianca;
import modelos.Crianca;
import modelos.Turma;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GUITurma extends JFrame {
    private JTextField idTurma;
    private JTextField turnoTurma;
    private JTextField idCriança;
    private JButton cadastrarbtn;
    private JButton matricularCriancabtn;
    private JButton verbtn;
    private JButton atualizarbtn;
    private JButton excluirbtn;
    private JButton voltarbtn;
    private ControlaTurma controlaTurma;

    public GUITurma() {
        setTitle("Cadastro de Turma");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout(FlowLayout.LEFT));

        JLabel idLabel = new JLabel("ID da turma:");
        idTurma = new JTextField(50);

        JLabel turnoLabel = new JLabel("Turno:");
        turnoTurma = new JTextField(50);

        JLabel id2Label = new JLabel("ID da Criança para cadastro na turma:");
        idCriança = new JTextField(50);

        JLabel dicaLabel = new JLabel("*** Para matricular criança em uma turma, preencha apenas os campos ID Turma e ID Criança ***");
        dicaLabel.setForeground(Color.BLUE);



        panel.add(idLabel);
        panel.add(idTurma);
        panel.add(turnoLabel);
        panel.add(turnoTurma);
        panel.add(id2Label);
        panel.add(idCriança);
        panel.add(dicaLabel);

        add(panel, BorderLayout.CENTER);


        JPanel buttonPanel = new JPanel();

        cadastrarbtn = new JButton("Cadastrar");
        matricularCriancabtn = new JButton("Matricular Criança");
        verbtn = new JButton("Ver");
        atualizarbtn = new JButton("Atualizar");
        excluirbtn = new JButton("Excluir");
        voltarbtn = new JButton("Voltar");

        buttonPanel.add(cadastrarbtn);
        buttonPanel.add(matricularCriancabtn);
        buttonPanel.add(verbtn);
        buttonPanel.add(atualizarbtn);
        buttonPanel.add(excluirbtn);
        buttonPanel.add(voltarbtn);

        add(buttonPanel, BorderLayout.SOUTH);

        controlaTurma = new ControlaTurma();
        ControlaCrianca controlaCrianca = new ControlaCrianca();

        cadastrarbtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String idTexto = idTurma.getText();
                String turno = turnoTurma.getText();
                String idCriancaTexto = idCriança.getText();

                if (idTexto.isEmpty() || turno.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "O ID e o Turno da turma são campos obrigatórios.", "Campos Vazios", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                int idTurma = 0;
                try {
                    idTurma = Integer.parseInt(idTexto);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "O ID da turma deve ser um número válido.", "ID Inválido", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (controlaTurma.getTurmaPorID(idTurma) != null) {
                    JOptionPane.showMessageDialog(null, "Turma com o mesmo ID já cadastrada. Use um ID único.", "ID Duplicado", JOptionPane.ERROR_MESSAGE);
                    return;
                }


                Turma turma = new Turma(idTurma, turno);

                if (controlaTurma.salvar(turma)) {
                    JOptionPane.showMessageDialog(null, "Turma cadastrada com sucesso.");
                } else {
                    JOptionPane.showMessageDialog(null, "Erro ao cadastrar a turma.", "Erro", JOptionPane.ERROR_MESSAGE);
                }

                if (!idCriancaTexto.isEmpty()) {
                    int idCrianca = Integer.parseInt(idCriancaTexto);
                    Crianca crianca = controlaCrianca.encontrarPorId(idCrianca);

                    if (crianca != null) {
                        Turma turmaExistente = controlaTurma.getTurmaPorID(idTurma);

                        if (turmaExistente != null) {
                            // Associa a criança à turma
                            turmaExistente.matricularCriancaPorID(idCrianca);
                            JOptionPane.showMessageDialog(null, "Criança cadastrada na turma com sucesso.");
                        } else {
                            JOptionPane.showMessageDialog(null, "Turma não encontrada com base no ID fornecido.", "Erro", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Criança não encontrada com base no ID fornecido.", "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });

        matricularCriancabtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String idTurmaTexto = idTurma.getText();
                String idCriancaTexto = idCriança.getText();

                if (idTurmaTexto.isEmpty() || idCriancaTexto.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Os campos ID da turma e ID da criança são obrigatórios.", "Campos Vazios", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    int idTurma = Integer.parseInt(idTurmaTexto);
                    int idCrianca = Integer.parseInt(idCriancaTexto);

                    // Verifica se a turma e a criança existem no sistema
                    Turma turmaExistente = controlaTurma.getTurmaPorID(idTurma);
                    Crianca criancaExistente = controlaCrianca.encontrarPorId(idCrianca);

                    if (turmaExistente != null && criancaExistente != null) {
                        // Verifica se a criança já está matriculada na turma
                        if (turmaExistente.matricularCriancaPorID(idCrianca)) {
                            JOptionPane.showMessageDialog(null, "A criança já está matriculada nesta turma.", "Criança Já Matriculada", JOptionPane.ERROR_MESSAGE);
                        } else {
                            // Matricula a criança na turma
                            turmaExistente.matricularCriancaPorID(idCrianca);
                            JOptionPane.showMessageDialog(null, "Criança matriculada na turma com sucesso.");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Turma e/ou criança não encontrada(s) com base no ID fornecido.", "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "O ID da turma e o ID da criança devem ser números válidos.", "IDs Inválidos", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        verbtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ArrayList<Turma> turmas = controlaTurma.retornarTodos();
                if (!turmas.isEmpty()) {
                    StringBuilder info = new StringBuilder("Turmas cadastradas:\n");
                    for (Turma turma : turmas) {
                        info.append("ID: ").append(turma.getIdTurma()).append(", Turno: ").append(turma.getTurno()).append("\n");

                        ArrayList<Crianca> criancasMatriculadas = turma.getCriancasMatriculadas();
                        if (!criancasMatriculadas.isEmpty()) {
                            info.append("Crianças Matriculadas:\n");
                            for (Crianca crianca : criancasMatriculadas) {
                                info.append("ID da Criança: ").append(crianca.getId()).append(", Nome: ").append(crianca.getNome()).append("\n");
                            }
                        }
                    }
                    JOptionPane.showMessageDialog(null, info.toString());
                } else {
                    JOptionPane.showMessageDialog(null, "Nenhuma turma cadastrada.");
                }
            }
        });




        atualizarbtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String idTexto = idTurma.getText();
                String novoTurno = turnoTurma.getText();

                if (idTexto.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "O campo ID da turma não pode estar vazio.", "Campo Vazio", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                int idTurma = 0;
                try {
                    idTurma = Integer.parseInt(idTexto);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "O ID da turma deve ser um número válido.", "ID Inválido", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Turma turmaExistente = controlaTurma.getTurmaPorID(idTurma);
                if (turmaExistente != null) {
                    // Atualize o turno da turma com o novo valor
                    turmaExistente.setTurno(novoTurno);
                    if (controlaTurma.atualizar(turmaExistente)) {
                        JOptionPane.showMessageDialog(null, "Turma atualizada com sucesso.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Erro ao atualizar a turma.", "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Turma não encontrada com base no ID.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        excluirbtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String idTexto = idTurma.getText();

                if (idTexto.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "O campo ID da turma não pode estar vazio.", "Campo Vazio", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                int idTurma = 0;
                try {
                    idTurma = Integer.parseInt(idTexto);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "O ID da turma deve ser um número válido.", "ID Inválido", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Turma turmaExistente = controlaTurma.getTurmaPorID(idTurma);
                if (turmaExistente != null) {
                    if (controlaTurma.excluir(turmaExistente)) {
                        JOptionPane.showMessageDialog(null, "Turma excluída com sucesso.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Erro ao excluir a turma.", "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Turma não encontrada com base no ID.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        voltarbtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Fecha a janela atual
                GUIPrincipal guiPrincipal = new GUIPrincipal();
                guiPrincipal.setVisible(true); // Exibe a janela principal
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                GUITurma janela = new GUITurma();
                janela.setVisible(true);
            }
        });
    }
}
