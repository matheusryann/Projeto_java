package colletion;

import modelos.Funcionario;

import java.util.ArrayList;

public class ControlaFuncionario {
    private static ArrayList<Funcionario> funcionarios = new ArrayList<>();

    public boolean cadastrar(Funcionario f) {
        try {
            if (f != null) {
                // Verifique se o funcionário já existe com base no ID (ou em outra chave única)
                for (Funcionario funcionarioExistente : funcionarios) {
                    if (funcionarioExistente.getId() == f.getId()) {
                        throw new IllegalArgumentException("Funcionário com o mesmo ID já existe.");
                    }
                }

                funcionarios.add(f);
                return true;
            } else {
                throw new IllegalArgumentException("Funcionário não pode ser nulo.");
            }
        } catch (IllegalArgumentException e) {
            System.err.println("Erro ao cadastrar funcionário: " + e.getMessage());
            return false;
        }
    }

    public boolean update(Funcionario f) {
        try {
            if (f != null) {
                for (int i = 0; i < funcionarios.size(); i++) {
                    if (funcionarios.get(i).getId() == f.getId()) {
                        funcionarios.set(i, f);
                        return true;
                    }
                }
                throw new IllegalArgumentException("Funcionário não encontrado com base no ID.");
            } else {
                throw new IllegalArgumentException("Funcionário não pode ser nulo.");
            }
        } catch (IllegalArgumentException e) {
            System.err.println("Erro ao atualizar funcionário: " + e.getMessage());
            return false;
        }
    }

    public boolean excluir(int id) {
        try {
            Funcionario funcionarioParaExcluir = null;
            for (Funcionario funcionario : funcionarios) {
                if (funcionario.getId() == id) {
                    funcionarioParaExcluir = funcionario;
                    break;
                }
            }

            if (funcionarioParaExcluir != null) {
                funcionarios.remove(funcionarioParaExcluir);
                return true;
            } else {
                throw new IllegalArgumentException("Funcionário não encontrado com base no ID.");
            }
        } catch (IllegalArgumentException e) {
            System.err.println("Erro ao excluir funcionário: " + e.getMessage());
            return false;
        }
    }

    public ArrayList<Funcionario> listar() {
        return new ArrayList<>(funcionarios); // Retorna uma cópia da lista de funcionários
    }

    public Funcionario buscarPorId(int id) {
        for (Funcionario funcionario : funcionarios) {
            if (funcionario.getId() == id) {
                return funcionario; // Retorna o funcionário se o ID coincidir
            }
        }
        return null; // Retorna null se o funcionário não for encontrado
    }
}