package colletion;
import modelos.Crianca;
import java.util.ArrayList;

public class ControlaCrianca {
    private static ArrayList<Crianca> criancas = new ArrayList<>();

    public boolean salvar(Crianca c) {
        try {
            if (c != null) {
                for (Crianca criancaExistente : criancas) {
                    if (criancaExistente.getId() == c.getId()) {
                        throw new IllegalArgumentException("Funcionário com o mesmo ID já existe.");
                    }
                }
                criancas.add(c);
                return true;
            } else {
                throw new IllegalArgumentException("Criança não pode ser nula.");
            }
        } catch (IllegalArgumentException e) {
            System.err.println("Erro ao salvar criança: " + e.getMessage());
            return false;
        }
    }

    public ArrayList<Crianca> retornarTodos() {
        return new ArrayList<>(criancas);
    }

    public boolean atualizar(Crianca c) {
        try {
            if (c != null) {
                int idParaAtualizar = c.getId();
                for (int i = 0; i < criancas.size(); i++) {
                    if (criancas.get(i).getId() == idParaAtualizar) {
                        criancas.set(i, c);
                        return true;
                    }
                }
                throw new IllegalArgumentException("Criança não encontrada com o ID fornecido.");
            } else {
                throw new IllegalArgumentException("Criança não pode ser nula.");
            }
        } catch (IllegalArgumentException e) {
            System.err.println("Erro ao atualizar criança: " + e.getMessage());
            return false;
        }
    }

    public Crianca getCriancaPorID(int id) {
        for (Crianca crianca : criancas) {
            if (crianca.getId() == id) {
                return crianca;
            }
        }
        return null;
    }


    public Crianca encontrarPorId(int id) {
        for (Crianca crianca : criancas) {
            if (crianca.getId() == id) {
                return crianca;
            }
        }
        return null; // Retorna null se a criança não for encontrada.
    }

    public boolean excluir(int id) {
       try {
           Crianca criancaParaExcluir = encontrarPorId(id);
            criancas.remove(criancaParaExcluir);
            return true;
        } catch(IllegalArgumentException e) {
           System.err.println("Erro ao excluir criança: " + e.getMessage());
           return false;
    }
}
}

