package colletion;

import modelos.Turma;

import java.util.ArrayList;

public class ControlaTurma {
    private static ArrayList<Turma> turmas = new ArrayList<Turma>();

    public boolean salvar(Turma turma) {
        if (turma != null) {
            turmas.add(turma);
            return true;
        }
        return false;
    }

    public static ArrayList<Turma> retornarTodos() {
        return turmas;
    }

    public boolean atualizar(Turma turmaAtualizada) {
        try {
            if (turmaAtualizada != null) {
                for (int i = 0; i < turmas.size(); i++) {
                    Turma turmaExistente = turmas.get(i);
                    if (turmaExistente.getIdTurma() == turmaAtualizada.getIdTurma()) {
                        turmas.set(i, turmaAtualizada);
                        return true;
                    }
                }
                throw new IllegalArgumentException("Turma não encontrada com base no ID.");
            } else {
                throw new IllegalArgumentException("Turma atualizada não pode ser nula.");
            }
        } catch (IllegalArgumentException e) {
            System.err.println("Erro ao atualizar turma: " + e.getMessage());
            return false;
        }
    }


    public boolean excluir(Turma turma) {
        if (turma != null) {
            if (turmas.remove(turma)) {
                return true;
            } else {
                throw new IllegalArgumentException("Turma não encontrada para exclusão.");
            }
        }
        throw new IllegalArgumentException("A turma não pode ser nula.");
    }

    public Turma getTurmaPorID(int id) {
        for (Turma turma : turmas) {
            if (turma.getIdTurma() == id) {
                return turma;
            }
        }
        return null; // Retorna null se a turma não for encontrada
    }

}
