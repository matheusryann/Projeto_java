package colletion;
import modelos.Departamento;
import java.util.ArrayList;

public class ControlaDepartamento {
    private static ArrayList<Departamento> departamentos = new ArrayList<>();

    public boolean salvar(Departamento d) {
        if (d != null) {
            departamentos.add(d);
            return true;
        } else {
            throw new IllegalArgumentException("O departamento não pode ser nulo.");
        }
    }

    public ArrayList<Departamento> retornarTodos() {
        return new ArrayList<>(departamentos);
    }

    public Departamento getDeparmanetoPorID(int id) {
        for (Departamento departamento : departamentos) {
            if (departamento.getId() == id) {
                return departamento;
            }
        }
        return null;
    }

    public boolean atualizar(Departamento departamentoAtualizado) {
        if (departamentoAtualizado != null) {
            Departamento departamentoParaAtualizar = getDeparmanetoPorID(departamentoAtualizado.getId());
            if (departamentoParaAtualizar != null) {
                int index = departamentos.indexOf(departamentoParaAtualizar);
                departamentos.set(index, departamentoAtualizado);
                return true;
            } else {
                throw new IllegalArgumentException("Departamento não encontrado para atualização.");
            }
        } else {
            throw new IllegalArgumentException("O departamento não pode ser nulo.");
        }
    }


    public boolean excluir(int id) {
        Departamento departamentoParaExcluir = getDeparmanetoPorID(id);
            if (departamentoParaExcluir != null) {
                return departamentos.remove(departamentoParaExcluir);
            } else {
                throw new IllegalArgumentException("Departamento não encontrado para exclusão.");
            }

}
}

