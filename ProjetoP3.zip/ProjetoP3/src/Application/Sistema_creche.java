package Application;

import modelos.Crianca;
import modelos.Turma;

import java.time.LocalDate;

public class Sistema_creche {
    public static void main(String[] args) {


    }
}
